# NIGHTLINERDRIVER – Autobahn-Geodaten

Ein GitHub-Actions-Workflow erzeugt aus dem Geofabrik-Deutschlandauszug monatlich kompakte, nach Autobahn getrennte OSM-Straßensegmente.

## Einrichtung

1. Dateien dieses Starterpakets in das Repository `pegelzwo/nightlinerdriver-geodata` hochladen; die Verzeichnisse `.github/workflows/` und `scripts/` müssen erhalten bleiben.
2. Unter **Settings → Actions → General → Workflow permissions** die Berechtigung **Read and write permissions** aktivieren, falls die Organisation/Repository-Einstellungen dies zulassen.
3. Unter **Actions → Deutsche Autobahn-Geodaten aufbereiten → Run workflow** den ersten Lauf starten.
4. Nach erfolgreichem Lauf stehen die Dateien unter **Releases → Autobahn-Geodaten** zur Verfügung, darunter `manifest.json` und `A1.json.gz`, `A2.json.gz` usw.

Die Dateien enthalten **unverbundene Autobahnabschnitte** und sind noch **nicht direkt für den GeoJSON-Upload des Nightlinerdriver-Websitesystems geeignet**. Für einen vollautomatischen Website-Import ist ein separater, kompatibler Importer erforderlich. Die Fahrtrichtungszuordnung und die Streckenkilometerberechnung sind noch nicht implementiert.

Quelle: © OpenStreetMap contributors (ODbL), Geofabrik. Beim Veröffentlichen/Verwenden Lizenz- und Attributionspflichten beachten.

Hinweis: Ein erster Lauf lädt mehrere GB herunter und kann je nach GitHub-Runner-Limits fehlschlagen. Die Plausibilitätsprüfung verhindert dann eine irreführende Veröffentlichung.
